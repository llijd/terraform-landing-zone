## Introduction

This example is used to create a `alicloud_slb_tls_cipher_policy` resource.

<!-- BEGIN_TF_DOCS -->
## Providers

| Name | Version |
|------|---------|
| <a name="provider_alicloud"></a> [alicloud](#provider\_alicloud) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [alicloud_slb_tls_cipher_policy.example](https://registry.terraform.io/providers/aliyun/alicloud/latest/docs/resources/slb_tls_cipher_policy) | resource |

## Inputs

No inputs.
<!-- END_TF_DOCS -->    