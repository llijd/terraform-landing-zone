## Introduction

This example is used to create a `alicloud_imp_app_template` resource.

<!-- BEGIN_TF_DOCS -->
## Providers

| Name | Version |
|------|---------|
| <a name="provider_alicloud"></a> [alicloud](#provider\_alicloud) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [alicloud_imp_app_template.example](https://registry.terraform.io/providers/aliyun/alicloud/latest/docs/resources/imp_app_template) | resource |

## Inputs

No inputs.
<!-- END_TF_DOCS -->    