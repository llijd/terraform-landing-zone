## Introduction

This example is used to create a `alicloud_alidns_record` resource.

<!-- BEGIN_TF_DOCS -->
## Providers

| Name | Version |
|------|---------|
| <a name="provider_alicloud"></a> [alicloud](#provider\_alicloud) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [alicloud_alidns_domain.default](https://registry.terraform.io/providers/aliyun/alicloud/latest/docs/resources/alidns_domain) | resource |
| [alicloud_alidns_domain_group.default](https://registry.terraform.io/providers/aliyun/alicloud/latest/docs/resources/alidns_domain_group) | resource |
| [alicloud_alidns_record.record](https://registry.terraform.io/providers/aliyun/alicloud/latest/docs/resources/alidns_record) | resource |

## Inputs

No inputs.
<!-- END_TF_DOCS -->    