## Introduction

This example is used to create a `alicloud_alidns_instance` resource.

<!-- BEGIN_TF_DOCS -->
## Providers

| Name | Version |
|------|---------|
| <a name="provider_alicloud"></a> [alicloud](#provider\_alicloud) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [alicloud_alidns_instance.example](https://registry.terraform.io/providers/aliyun/alicloud/latest/docs/resources/alidns_instance) | resource |

## Inputs

No inputs.
<!-- END_TF_DOCS -->    