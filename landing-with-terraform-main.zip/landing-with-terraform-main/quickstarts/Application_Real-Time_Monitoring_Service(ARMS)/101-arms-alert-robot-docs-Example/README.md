## Introduction

This example is used to create a `alicloud_arms_alert_robot` resource.

<!-- BEGIN_TF_DOCS -->
## Providers

| Name | Version |
|------|---------|
| <a name="provider_alicloud"></a> [alicloud](#provider\_alicloud) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [alicloud_arms_alert_robot.dingding](https://registry.terraform.io/providers/aliyun/alicloud/latest/docs/resources/arms_alert_robot) | resource |
| [alicloud_arms_alert_robot.feishu](https://registry.terraform.io/providers/aliyun/alicloud/latest/docs/resources/arms_alert_robot) | resource |
| [alicloud_arms_alert_robot.wechat](https://registry.terraform.io/providers/aliyun/alicloud/latest/docs/resources/arms_alert_robot) | resource |

## Inputs

No inputs.
<!-- END_TF_DOCS -->
