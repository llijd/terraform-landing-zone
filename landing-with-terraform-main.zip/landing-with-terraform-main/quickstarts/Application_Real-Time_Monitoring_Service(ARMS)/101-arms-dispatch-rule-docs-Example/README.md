## Introduction

This example is used to create a `alicloud_arms_dispatch_rule` resource.

<!-- BEGIN_TF_DOCS -->
## Providers

| Name | Version |
|------|---------|
| <a name="provider_alicloud"></a> [alicloud](#provider\_alicloud) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [alicloud_arms_alert_contact.default](https://registry.terraform.io/providers/aliyun/alicloud/latest/docs/resources/arms_alert_contact) | resource |
| [alicloud_arms_alert_contact_group.default](https://registry.terraform.io/providers/aliyun/alicloud/latest/docs/resources/arms_alert_contact_group) | resource |
| [alicloud_arms_dispatch_rule.default](https://registry.terraform.io/providers/aliyun/alicloud/latest/docs/resources/arms_dispatch_rule) | resource |

## Inputs

No inputs.
<!-- END_TF_DOCS -->    