## Introduction

This example is used to create a `alicloud_chatbot_publish_task` resource.

<!-- BEGIN_TF_DOCS -->
## Providers

| Name | Version |
|------|---------|
| <a name="provider_alicloud"></a> [alicloud](#provider\_alicloud) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [alicloud_chatbot_publish_task.default](https://registry.terraform.io/providers/aliyun/alicloud/latest/docs/resources/chatbot_publish_task) | resource |
| [alicloud_chatbot_agents.default](https://registry.terraform.io/providers/aliyun/alicloud/latest/docs/data-sources/chatbot_agents) | data source |

## Inputs

No inputs.
<!-- END_TF_DOCS -->    