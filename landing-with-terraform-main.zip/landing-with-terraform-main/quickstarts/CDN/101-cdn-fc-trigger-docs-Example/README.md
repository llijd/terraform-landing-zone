## Introduction

This example is used to create a `alicloud_cdn_fc_trigger` resource.

<!-- BEGIN_TF_DOCS -->
## Providers

| Name | Version |
|------|---------|
| <a name="provider_alicloud"></a> [alicloud](#provider\_alicloud) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [alicloud_cdn_fc_trigger.example](https://registry.terraform.io/providers/aliyun/alicloud/latest/docs/resources/cdn_fc_trigger) | resource |
| [alicloud_account.default](https://registry.terraform.io/providers/aliyun/alicloud/latest/docs/data-sources/account) | data source |
| [alicloud_regions.default](https://registry.terraform.io/providers/aliyun/alicloud/latest/docs/data-sources/regions) | data source |

## Inputs

No inputs.
<!-- END_TF_DOCS -->    